フォントは、以下のフォントを利用させて頂いております

源真ゴシック
http://jikasei.me/font/genshin/

源抜ゴシック
http://blueskis.wktk.so/GenEiGenNuki/
